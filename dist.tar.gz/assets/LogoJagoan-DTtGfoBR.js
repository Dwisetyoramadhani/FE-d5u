const o="/assets/LogoJagoan-DoQbvpUd.png";export{o as g};
