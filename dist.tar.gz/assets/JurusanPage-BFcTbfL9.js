import{j as r}from"./index-BSKxGgvy.js";import t from"./Jurusan-bKD2T8Nm.js";import"./createLucideIcon-BhspLwHY.js";const e=()=>r.jsx(r.Fragment,{children:r.jsx(t,{})});export{e as default};
