const g="/assets/foto-lulusan-gzZfgugT.png";export{g};
