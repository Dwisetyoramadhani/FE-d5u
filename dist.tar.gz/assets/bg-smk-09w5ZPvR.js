const s="/assets/bg-smk-CDmkNyCb.webp";export{s as b};
