const s="/assets/headgp-ym-NkDVT.jpg";export{s as G};
