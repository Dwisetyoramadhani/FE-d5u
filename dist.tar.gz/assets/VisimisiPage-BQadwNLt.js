import{j as i}from"./index-BSKxGgvy.js";import s from"./VisiMisi-DTvb0aqP.js";const e=()=>i.jsx(i.Fragment,{children:i.jsx(s,{})});export{e as default};
